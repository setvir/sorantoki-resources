

<?php $__env->startSection('title', 'Forum'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4">Community Forum</h1>

    <div class="row g-4">
        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title">
                            <a href="<?php echo e(route('forum.section', $section)); ?>" class="text-decoration-none">
                                <?php echo e($section->name); ?>

                            </a>
                        </h5>
                        <p class="card-text text-muted"><?php echo e($section->description); ?></p>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="badge bg-primary"><?php echo e($section->posts_count); ?> posts</span>
                            <a href="<?php echo e(route('forum.section', $section)); ?>" class="btn btn-sm btn-outline-primary">
                                Browse →
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php if(auth()->guard()->guest()): ?>
        <div class="alert alert-info mt-4">
            <a href="<?php echo e(route('login')); ?>">Login</a> or <a href="<?php echo e(route('register')); ?>">register</a> to create posts and join discussions.
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\it\sorantoki\resources\views/forum/index.blade.php ENDPATH**/ ?>