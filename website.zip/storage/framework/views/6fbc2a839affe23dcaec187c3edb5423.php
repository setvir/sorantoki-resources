

<?php $__env->startSection('title', 'Licensing Policy'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-3">
            <div class="card sticky-top" style="top: 20px;">
                <div class="card-header">
                    <h6 class="mb-0">Licensing</h6>
                </div>
                <div class="card-body">
                    <nav class="nav flex-column small">
                        <a class="nav-link" href="#speaking">Speaking & Use</a>
                        <a class="nav-link" href="#grammar">Grammar Reference</a>
                        <a class="nav-link" href="#lexicon">Lexicon</a>
                        <a class="nav-link" href="#trademarks">Trademarks</a>
                        <a class="nav-link" href="#summary">Summary</a>
                    </nav>
                </div>
            </div>
        </div>

        <div class="col-lg-9">
            <h1 class="mb-4">Sorantoki Licensing Policy</h1>

            <div class="alert alert-info">
                <p class="mb-0">All Sorantoki materials are freely available under Creative Commons licenses. This page explains what you can and cannot do with different parts of the project.</p>
            </div>

            <!-- 1. Speaking & Use -->
            <section id="speaking" class="mb-5">
                <h2>1. Speaking, Writing, and Creation</h2>
                <div class="card border-success">
                    <div class="card-body">
                        <p class="card-text">Speaking, writing, singing, filming, or creating in Sorantoki is completely <strong>free for any purpose</strong> (personal, artistic, or commercial). No permission or attribution is ever required.</p>
                        <p class="mb-0"><strong>License:</strong> <a href="https://creativecommons.org/publicdomain/zero/1.0/" class="text-success" target="_blank">CC0 1.0 Universal (Public Domain)</a></p>
                    </div>
                </div>
            </section>

            <!-- 2. Grammar Reference -->
            <section id="grammar" class="mb-5">
                <h2>2. Grammar Reference & Explanatory Materials</h2>
                <div class="card border-primary">
                    <div class="card-body">
                        <p class="card-text">The official grammar reference and all explanatory materials are licensed under:</p>
                        <h5 class="text-primary mb-3">
                            <a href="https://creativecommons.org/licenses/by-sa/4.0/" target="_blank">Creative Commons Attribution-ShareAlike 4.0 International (CC-BY-SA 4.0)</a>
                        </h5>
                        
                        <h6 class="mt-4">You may:</h6>
                        <ul>
                            <li>Create and sell derivative learning materials, courses, books, or apps based on the grammar</li>
                            <li>Share and adapt the content for any purpose</li>
                        </ul>

                        <h6>Attribution Requirements:</h6>
                        <ul>
                            <li>Give appropriate credit to Sorantoki</li>
                            <li>Link back to <a href="https://sorantoki.org">sorantoki.org</a></li>
                            <li>License your derivatives under CC-BY-SA 4.0</li>
                            <li>Clearly indicate your work is not the official version</li>
                        </ul>

                        <div class="alert alert-warning mt-3 mb-0">
                            <strong>Restriction:</strong> The canonical grammar PDF itself may not be sold or placed behind a paywall. It must remain freely accessible.
                        </div>
                    </div>
                </div>
            </section>

            <!-- 3. Lexicon -->
            <section id="lexicon" class="mb-5">
                <h2>3. Official Lexicon</h2>
                <div class="card border-info">
                    <div class="card-body">
                        <p class="card-text">The official lexicon (word list, including coiner credits) is licensed under:</p>
                        <h5 class="text-info mb-3">
                            <a href="https://creativecommons.org/licenses/by/4.0/" target="_blank">Creative Commons Attribution 4.0 International (CC-BY 4.0)</a>
                        </h5>

                        <h6 class="mt-4">You may:</h6>
                        <ul>
                            <li>Create and sell derivative works: apps, flashcards, annotated dictionaries, teaching tools</li>
                            <li>Share and adapt the lexicon for any purpose</li>
                        </ul>

                        <h6>Attribution Requirements:</h6>
                        <ul>
                            <li>Give appropriate credit to Sorantoki</li>
                            <li>Link back to <a href="https://sorantoki.org">sorantoki.org</a></li>
                            <li>License your derivatives under CC-BY 4.0</li>
                        </ul>

                        <div class="alert alert-warning mt-3 mb-0">
                            <strong>Restriction:</strong> The canonical lexicon itself may not be sold or placed behind a paywall. It must remain freely accessible.
                        </div>
                    </div>
                </div>
            </section>

            <!-- 4. Trademarks -->
            <section id="trademarks" class="mb-5">
                <h2>4. Trademarks</h2>
                <div class="card border-warning">
                    <div class="card-body">
                        <p class="card-text">The name <strong>"Sorantoki"</strong> and the official logo are unregistered trademarks (™) of the Sorantoki project.</p>
                        <p class="mb-0">You may use them only to refer to the language itself or to official resources.</p>
                    </div>
                </div>
            </section>

            <!-- Summary -->
            <section id="summary" class="mb-5">
                <h2>In Short</h2>
                <div class="alert alert-success">
                    <ul class="mb-0">
                        <li>✅ <strong>Use the language forever, for free, for anything.</strong></li>
                        <li>✅ <strong>Create and sell learning materials</strong> based on the grammar/lexicon with attribution and same license.</li>
                        <li>❌ <strong>Never sell or paywall the canonical grammar PDF or lexicon</strong> themselves.</li>
                        <li>❌ <strong>Never remove credits</strong> or claim Sorantoki as your own creation.</li>
                    </ul>
                </div>
            </section>

            <div class="text-center mt-5">
                <p class="text-muted small">
                    For questions about licensing, contact <a href="mailto:legal@sorantoki.org">legal@sorantoki.org</a>
                </p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\it\sorantoki\resources\views/lisence.blade.php ENDPATH**/ ?>