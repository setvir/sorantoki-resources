

<?php $__env->startSection('title', $section->name); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('forum.index')); ?>">Forum</a></li>
            <li class="breadcrumb-item active"><?php echo e($section->name); ?></li>
        </ol>
    </nav>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1><?php echo e($section->name); ?></h1>
            <p class="text-muted"><?php echo e($section->description); ?></p>
        </div>
        <?php if(auth()->guard()->check()): ?>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#newPostModal">
                New Post
            </button>
        <?php endif; ?>
    </div>

    <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card mb-3">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <h5 class="card-title">
                        <a href="<?php echo e(route('forum.post.show', [$section, $post])); ?>" class="text-decoration-none">
                            <?php if($post->is_pinned): ?> 📌 <?php endif; ?>
                            <?php echo e($post->title); ?>

                        </a>
                    </h5>
                    <span class="badge bg-secondary"><?php echo e($post->comments->count()); ?> comments</span>
                </div>
                <p class="card-text"><?php echo e(Str::limit($post->content, 200)); ?></p>
                <small class="text-muted">
                    Posted by <?php echo e($post->user->name); ?> on <?php echo e($post->created_at->format('M d, Y')); ?>

                </small>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="alert alert-info">
            No posts yet. Be the first to start a discussion!
        </div>
    <?php endif; ?>

    <div class="mt-4">
        <?php echo e($posts->links()); ?>

    </div>
</div>

<?php if(auth()->guard()->check()): ?>
<!-- New Post Modal -->
<div class="modal fade" id="newPostModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">New Post in <?php echo e($section->name); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="<?php echo e(route('forum.post.store', $section)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="title" class="form-label">Title</label>
                        <input type="text" class="form-control" id="title" name="title" required>
                    </div>
                    <div class="mb-3">
                        <label for="content" class="form-label">Content</label>
                        <textarea class="form-control" id="content" name="content" rows="5" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Post</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\it\sorantoki\resources\views/forum/section.blade.php ENDPATH**/ ?>