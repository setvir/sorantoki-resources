<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12" fill="none" <?php echo e($attributes); ?>>
  <g clip-path="url(#clip0_14732_6079)">
    <path d="M4.25 4.25012V1.25012H10.75V7.75012H7.75M7.75 4.25012H1.25V10.7501H7.75V4.25012Z" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/>
  </g>
  <defs>
    <clipPath id="clip0_14732_6079">
      <rect width="12" height="12" />
    </clipPath>
  </defs>
</svg>
<?php /**PATH C:\Users\it\sorantoki\vendor\laravel\framework\src\Illuminate\Foundation\Providers/../resources/exceptions/renderer/components/icons/copy.blade.php ENDPATH**/ ?>