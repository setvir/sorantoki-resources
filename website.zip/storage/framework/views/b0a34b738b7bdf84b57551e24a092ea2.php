

<?php $__env->startSection('title', $entry->root); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dictionary.index')); ?>">Dictionary</a></li>
                    <li class="breadcrumb-item active"><?php echo e($entry->root); ?></li>
                </ol>
            </nav>

            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h2 class="mb-0"><?php echo e($entry->root); ?></h2>
                </div>
                <div class="card-body">
                    <?php if($entry->word_class): ?>
                        <p class="text-muted"><em><?php echo e($entry->word_class); ?></em></p>
                    <?php endif; ?>

                    <h5>Definition</h5>
                    <p><?php echo e($entry->definition); ?></p>

                    <?php if($entry->examples): ?>
                        <h5 class="mt-4">Examples</h5>
                        <div class="bg-light p-3 rounded">
                            <?php echo nl2br(e($entry->examples)); ?>

                        </div>
                    <?php endif; ?>

                    <?php if($entry->notes): ?>
                        <h5 class="mt-4">Notes</h5>
                        <p><?php echo e($entry->notes); ?></p>
                    <?php endif; ?>

                    <hr class="my-4">

                    <div class="row">
                        <div class="col-md-6">
                            <strong>Status:</strong>
                            <?php if($entry->status === 'canonical'): ?>
                                <span class="badge bg-success">Canonical</span>
                            <?php else: ?>
                                <span class="badge bg-warning">Provisional</span>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <?php if($entry->canonized_at): ?>
                                <strong>Canonized:</strong> <?php echo e($entry->canonized_at->format('M d, Y')); ?>

                            <?php endif; ?>
                        </div>
                    </div>

                    <?php if($entry->coined_by): ?>
                        <div class="mt-3">
                            <strong>Coined by:</strong> <?php echo e($entry->coiner->name); ?>

                            <?php if($entry->vote_percentage): ?>
                                with <?php echo e($entry->vote_percentage); ?>% community approval
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <?php if($entry->isProvisional()): ?>
                        <div class="alert alert-info mt-3">
                            This root is still provisional and can be replaced by community vote within 
                            <?php echo e($entry->canonized_at->addYears(2)->diffForHumans()); ?>.
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="mt-3">
                <a href="<?php echo e(route('dictionary.index')); ?>" class="btn btn-secondary">Back to Dictionary</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\it\sorantoki\resources\views/dictionary/show.blade.php ENDPATH**/ ?>