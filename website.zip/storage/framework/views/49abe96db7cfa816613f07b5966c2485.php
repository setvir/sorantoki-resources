

<?php $__env->startSection('title', 'Dictionary'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mb-4">
        <div class="col-md-8">
            <h1>Sorantoki Dictionary</h1>
            <p class="text-muted">Browse <?php echo e($entries->total()); ?> roots</p>
        </div>
        <div class="col-md-4">
            <form action="<?php echo e(route('dictionary.search')); ?>" method="GET">
                <div class="input-group">
                    <input type="text" 
                           name="q" 
                           class="form-control" 
                           placeholder="Search roots or definitions..." 
                           value="<?php echo e($query ?? ''); ?>">
                    <button class="btn btn-primary" type="submit">
                        <i class="bi bi-search"></i> Search
                    </button>
                </div>
            </form>
        </div>
    </div>

    <?php if(isset($query)): ?>
        <div class="alert alert-info">
            Showing results for: <strong><?php echo e($query); ?></strong>
            <a href="<?php echo e(route('dictionary.index')); ?>" class="float-end">Clear search</a>
        </div>
    <?php endif; ?>

    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-6 mb-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">
                            <a href="<?php echo e(route('dictionary.show', $entry)); ?>" class="text-decoration-none">
                                <?php echo e($entry->root); ?>

                            </a>
                            <?php if($entry->status === 'canonical'): ?>
                                <span class="badge bg-success" style="float:right">Canonical</span>
                            <?php else: ?>
                                <span class="badge bg-warning" style="float:right">Provisional</span>
                            <?php endif; ?>
                        </h5>
                        <?php if($entry->word_class): ?>
                            <p class="text-muted small mb-1"><?php echo e($entry->word_class); ?></p>
                        <?php endif; ?>
                        <p class="card-text"><?php echo e(Str::limit($entry->definition, 100)); ?></p>
                        <?php if($entry->coined_by): ?>
                            <p class="small text-muted mb-0">
                                Coined by: <?php echo e($entry->coiner->name); ?>

                                <?php if($entry->vote_percentage): ?>
                                    (<?php echo e($entry->vote_percentage); ?>% approval)
                                <?php endif; ?>
                            </p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <div class="alert alert-warning">
                    No entries found. <?php if(isset($query)): ?> Try a different search. <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <div class="mt-4">
        <?php echo e($entries->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\it\sorantoki\resources\views/dictionary/index.blade.php ENDPATH**/ ?>