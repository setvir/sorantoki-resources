

<?php $__env->startSection('title', 'Active Polls'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4">Active Polls</h1>

    <div class="alert alert-info">
        <strong>Ranked-Choice Voting:</strong> Rank the proposals in order of preference. 
        Your first choice gets the most weight, followed by your second and third choices.
    </div>

    <?php $__empty_1 = true; $__currentLoopData = $activePolls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><?php echo e($poll->frictionReport->concept); ?></h5>
            </div>
            <div class="card-body">
                <p><?php echo e($poll->frictionReport->description); ?></p>
                
                <div class="row mt-3">
                    <div class="col-md-6">
                        <small class="text-muted">
                            <strong>Ends:</strong> <?php echo e($poll->ends_at->format('M d, Y g:i A')); ?>

                            (<?php echo e($poll->ends_at->diffForHumans()); ?>)
                        </small>
                    </div>
                    <div class="col-md-6 text-end">
                        <small class="text-muted">
                            <strong>Votes:</strong> <?php echo e($poll->votes()->distinct('user_id')->count()); ?>

                            <?php if($poll->min_votes): ?>
                                / <?php echo e($poll->min_votes); ?> required
                            <?php endif; ?>
                        </small>
                    </div>
                </div>

                <a href="<?php echo e(route('polls.show', $poll)); ?>" class="btn btn-primary mt-3">
                    View & Vote
                </a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="alert alert-warning">
            No active polls at the moment. Check back later!
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\it\sorantoki\resources\views/polls/index.blade.php ENDPATH**/ ?>