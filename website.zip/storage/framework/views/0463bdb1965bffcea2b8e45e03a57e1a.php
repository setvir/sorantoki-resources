

<?php $__env->startSection('title', 'Friction Reports'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1>Friction Reports</h1>
            <p class="text-muted">Community-identified concepts that need new words</p>
        </div>
        <a href="<?php echo e(route('friction.create')); ?>" class="btn btn-primary">Submit New Report</a>
    </div>

    <div class="alert alert-info">
        <strong>How it works:</strong> Submit concepts that need new words. The community upvotes the most needed ones. 
        Every Sunday, curators select 3-5 top concepts for root proposals and voting.
    </div>

    <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card mb-3">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-8">
                        <h5 class="card-title"><?php echo e($report->concept); ?></h5>
                        <p class="card-text"><?php echo e($report->description); ?></p>
                        
                        <?php if($report->examples): ?>
                            <div class="small text-muted">
                                <strong>Examples:</strong> <?php echo e(Str::limit($report->examples, 150)); ?>

                            </div>
                        <?php endif; ?>

                        <div class="mt-2">
                            <small class="text-muted">
                                Submitted by <?php echo e($report->user->name); ?> on <?php echo e($report->created_at->format('M d, Y')); ?>

                            </small>
                        </div>

                        <?php if($report->proposals->count() > 0): ?>
                            <div class="mt-2">
                                <span class="badge bg-info"><?php echo e($report->proposals->count()); ?> proposals</span>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="col-md-4 text-end">
                        <div class="display-6 text-primary"><?php echo e($report->upvotes); ?></div>
                        <div class="text-muted small">upvotes</div>
                        
                        <form action="<?php echo e(route('friction.upvote', $report)); ?>" method="POST" class="mt-2">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-sm btn-outline-primary">
                                👍 Upvote
                            </button>
                        </form>

                        <?php if($report->status === 'selected'): ?>
                            <span class="badge bg-success mt-2">Selected for voting</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="alert alert-warning">
            No friction reports yet. Be the first to submit one!
        </div>
    <?php endif; ?>

    <div class="mt-4">
        <?php echo e($reports->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\it\sorantoki\resources\views/friction/index.blade.php ENDPATH**/ ?>