<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('dictionary_entries', function (Blueprint $table) {
            $table->id();
            $table->string('root');
            $table->text('definition');
            $table->string('word_class')->nullable();
            $table->text('examples')->nullable();
            $table->text('notes')->nullable();
            $table->enum('status', ['provisional', 'canonical'])->default('provisional');
            $table->timestamp('canonized_at')->nullable();
            $table->foreignId('coined_by')->nullable()->constrained('users');
            $table->integer('vote_percentage')->nullable();
            $table->timestamps();
            
            $table->index('root');
            $table->index('status');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('dictionary_entries');
    }
};
