<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\ForumSection;

class ForumSectionSeeder extends Seeder
{
    public function run(): void
    {
        $sections = [
            ['name' => 'General', 'slug' => 'general', 'description' => 'General discussions about Sorantoki', 'order' => 1],
            ['name' => 'Roots', 'slug' => 'roots', 'description' => 'Discussions about word roots and etymology', 'order' => 2],
            ['name' => 'Grammar', 'slug' => 'grammar', 'description' => 'Grammar questions and discussions', 'order' => 3],
        ];

        foreach ($sections as $section) {
            ForumSection::create($section);
        }
    }
}
