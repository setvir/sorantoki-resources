<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\DictionaryEntry;
use Illuminate\Support\Facades\File;
use Carbon\Carbon;

class DictionarySeeder extends Seeder
{
    public function run(): void
    {
        $path = base_path('database/seeders/data/dictionary.txt');

        if (!File::exists($path)) {
            $this->command->error("dictionary.txt not found at: " . $path);
            return;
        }

        $lines = File::lines($path);

        foreach ($lines as $line) {
            $line = trim($line);

            // Skip empty lines
            if ($line === '') continue;

            // Expected format:  english<TAB>sorantoki
            // Example: "above/on top    ata"
            if (!str_contains($line, "\t")) {
                $this->command->warn("Skipped malformed line: " . $line);
                continue;
            }

            [$definition, $root] = explode("\t", $line);

            DictionaryEntry::create([
                'root'            => trim($root),
                'definition'      => trim($definition),

                // Optional fields:
                'word_class'      => null,
                'examples'        => null,
                'notes'           => null,

                // Canonical settings
                'status'          => 'canonical',
                'coined_by'       => 1, // or a numeric user_id
                'vote_percentage' => 100,
                'canonized_at'    => Carbon::now(),
            ]);
        }

        $this->command->info("Dictionary seeded successfully.");
    }
}
