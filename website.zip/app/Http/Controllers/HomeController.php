<?php
namespace App\Http\Controllers;

use App\Models\DictionaryEntry;
use App\Models\FrictionReport;
use App\Models\Poll;

class HomeController extends Controller
{
    public function index()
    {
        $stats = [
            'total_roots' => DictionaryEntry::count(),
            'canonical_roots' => DictionaryEntry::where('status', 'canonical')->count(),
            'active_polls' => Poll::where('status', 'active')->count(),
            'pending_reports' => FrictionReport::where('status', 'pending')->count(),
        ];

        return view('home', compact('stats'));
    }

    public function grammar()
    {
        return view('grammar');
    }

    public function lisence()
    {
        return view('lisence');
    }
}
