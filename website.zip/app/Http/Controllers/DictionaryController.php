<?php
namespace App\Http\Controllers;

use App\Models\DictionaryEntry;
use Illuminate\Http\Request;

class DictionaryController extends Controller
{
    public function index()
    {
        $entries = DictionaryEntry::orderBy('root')->paginate(50);
        return view('dictionary.index', compact('entries'));
    }

    public function search(Request $request)
    {
        $query = $request->get('q');
        
        $entries = DictionaryEntry::where('root', 'like', "%{$query}%")
            ->orWhere('definition', 'like', "%{$query}%")
            ->orderBy('root')
            ->paginate(50);

        return view('dictionary.index', compact('entries', 'query'));
    }

    public function show(DictionaryEntry $entry)
    {
        return view('dictionary.show', compact('entry'));
    }
}