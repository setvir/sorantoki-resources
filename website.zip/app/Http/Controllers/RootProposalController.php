<?php
namespace App\Http\Controllers;

use App\Models\FrictionReport;
use App\Models\RootProposal;
use Illuminate\Http\Request;

class RootProposalController extends Controller
{
    public function store(Request $request, FrictionReport $report)
    {
        // Check if user already has 3 proposals for this report
        $existingCount = RootProposal::where('friction_report_id', $report->id)
            ->where('user_id', auth()->id())
            ->count();

        if ($existingCount >= 3) {
            return back()->withErrors(['error' => 'You can only submit up to 3 proposals per friction report.']);
        }

        $validated = $request->validate([
            'proposed_root' => 'required|string|max:50',
            'justification' => 'nullable|string',
            'sources' => 'nullable|string',
        ]);

        RootProposal::create([
            'friction_report_id' => $report->id,
            'user_id' => auth()->id(),
            'proposed_root' => $validated['proposed_root'],
            'justification' => $validated['justification'] ?? null,
            'sources' => $validated['sources'] ?? null,
        ]);

        return back()->with('success', 'Proposal submitted successfully!');
    }
}