<?php
namespace App\Http\Controllers;

use App\Models\Poll;
use App\Models\PollVote;
use Illuminate\Http\Request;

class PollController extends Controller
{
    public function index()
    {
        $activePolls = Poll::with('frictionReport')
            ->where('status', 'active')
            ->orderBy('ends_at')
            ->get();

        return view('polls.index', compact('activePolls'));
    }

    public function show(Poll $poll)
    {
        $poll->load(['frictionReport.proposals.user', 'votes']);
        
        $userVotes = null;
        if (auth()->check()) {
            $userVotes = PollVote::where('poll_id', $poll->id)
                ->where('user_id', auth()->id())
                ->pluck('root_proposal_id', 'rank')
                ->toArray();
        }

        return view('polls.show', compact('poll', 'userVotes'));
    }

    public function vote(Request $request, Poll $poll)
    {
        if (!$poll->isActive()) {
            return back()->withErrors(['error' => 'This poll is no longer active.']);
        }

        $validated = $request->validate([
            'rankings' => 'required|array',
            'rankings.*' => 'exists:root_proposals,id',
        ]);

        // Delete existing votes
        PollVote::where('poll_id', $poll->id)
            ->where('user_id', auth()->id())
            ->delete();

        // Create new votes
        foreach ($validated['rankings'] as $rank => $proposalId) {
            PollVote::create([
                'poll_id' => $poll->id,
                'user_id' => auth()->id(),
                'root_proposal_id' => $proposalId,
                'rank' => $rank + 1,
            ]);
        }

        return back()->with('success', 'Your vote has been recorded!');
    }
}