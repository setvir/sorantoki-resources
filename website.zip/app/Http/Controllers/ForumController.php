<?php
namespace App\Http\Controllers;

use App\Models\ForumSection;
use App\Models\ForumPost;
use App\Models\ForumComment;
use Illuminate\Http\Request;

class ForumController extends Controller
{
    public function index()
    {
        $sections = ForumSection::withCount('posts')->orderBy('order')->get();
        return view('forum.index', compact('sections'));
    }

    public function section(ForumSection $section)
    {
        $posts = ForumPost::where('section_id', $section->id)
            ->with('user', 'comments')
            ->orderBy('is_pinned', 'desc')
            ->orderBy('created_at', 'desc')
            ->paginate(20);

        return view('forum.section', compact('section', 'posts'));
    }

    public function show(ForumSection $section, ForumPost $post)
    {
        $post->load(['user', 'comments.user']);
        return view('forum.show', compact('section', 'post'));
    }

    public function storePost(Request $request, ForumSection $section)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'content' => 'required|string',
        ]);

        ForumPost::create([
            'section_id' => $section->id,
            'user_id' => auth()->id(),
            'title' => $validated['title'],
            'content' => $validated['content'],
        ]);

        return redirect()->route('forum.section', $section)
            ->with('success', 'Post created successfully!');
    }

    public function storeComment(Request $request, ForumPost $post)
    {
        $validated = $request->validate([
            'content' => 'required|string',
        ]);

        ForumComment::create([
            'post_id' => $post->id,
            'user_id' => auth()->id(),
            'content' => $validated['content'],
        ]);

        return back()->with('success', 'Comment added!');
    }
}