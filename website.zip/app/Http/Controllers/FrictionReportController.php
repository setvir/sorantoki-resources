<?php
namespace App\Http\Controllers;

use App\Models\FrictionReport;
use Illuminate\Http\Request;

class FrictionReportController extends Controller
{
    public function index()
    {
        $reports = FrictionReport::with('user', 'proposals')
            ->where('status', 'pending')
            ->orderBy('upvotes', 'desc')
            ->orderBy('created_at', 'desc')
            ->paginate(20);

        return view('friction.index', compact('reports'));
    }

    public function create()
    {
        return view('friction.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'concept' => 'required|string|max:255',
            'description' => 'required|string',
            'examples' => 'nullable|string',
        ]);

        $report = FrictionReport::create([
            'user_id' => auth()->id(),
            'concept' => $validated['concept'],
            'description' => $validated['description'],
            'examples' => $validated['examples'] ?? null,
            'status' => 'pending',
        ]);

        return redirect()->route('friction.index')
            ->with('success', 'Friction report submitted successfully!');
    }

    public function upvote(FrictionReport $report)
    {
        $report->increment('upvotes');
        return back()->with('success', 'Upvoted!');
    }
}