<?php

// app/Http/Controllers/Admin/DashboardController.php
namespace App\Http\Controllers\Admin;

use App\Models\Poll;
use App\Models\PollVote;
use App\Models\ForumPost;
use App\Models\RootProposal;
use App\Models\ForumSection;
use App\Models\FrictionReport;
use App\Models\DictionaryEntry;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        $stats = [
            'total_entries' => DictionaryEntry::count(),
            'pending_reports' => FrictionReport::where('status', 'pending')->count(),
            'active_polls' => Poll::where('status', 'active')->count(),
            'selected_reports' => FrictionReport::where('status', 'selected')->count(),
        ];

        $pendingReports = FrictionReport::where('status', 'pending')
            ->orderBy('upvotes', 'desc')
            ->take(10)
            ->get();

        $activePolls = Poll::with('frictionReport')
            ->where('status', 'active')
            ->orderBy('ends_at')
            ->get();

        return view('admin.dashboard', compact('stats', 'pendingReports', 'activePolls'));
    }

    public function dictionary()
    {
        $entries = DictionaryEntry::with('coiner')
            ->orderBy('created_at', 'desc')
            ->paginate(20);

        return view('admin.dictionary', compact('entries'));
    }

    public function storeDictionary(Request $request)
    {
        $validated = $request->validate([
            'root' => 'required|string|max:50|unique:dictionary_entries,root',
            'definition' => 'required|string',
            'word_class' => 'nullable|string|max:50',
            'examples' => 'nullable|string',
            'notes' => 'nullable|string',
            'status' => 'required|in:provisional,canonical',
        ]);

        $entry = DictionaryEntry::create([
            ...$validated,
            'coined_by' => auth()->id(),
            'canonized_at' => $validated['status'] === 'canonical' ? now() : null,
        ]);

        return back()->with('success', 'Dictionary entry created successfully!');
    }

    public function updateDictionary(Request $request, DictionaryEntry $entry)
    {
        $validated = $request->validate([
            'root' => 'required|string|max:50|unique:dictionary_entries,root,' . $entry->id,
            'definition' => 'required|string',
            'word_class' => 'nullable|string|max:50',
            'examples' => 'nullable|string',
            'notes' => 'nullable|string',
            'status' => 'required|in:provisional,canonical',
        ]);

        $entry->update($validated);

        return back()->with('success', 'Dictionary entry updated successfully!');
    }

    public function deleteDictionary(DictionaryEntry $entry)
    {
        $entry->delete();
        return back()->with('success', 'Dictionary entry deleted successfully!');
    }

    public function selectFrictionReport(FrictionReport $report)
    {
        $report->update(['status' => 'selected']);
        return back()->with('success', 'Friction report selected for proposals!');
    }

    public function rejectFrictionReport(FrictionReport $report)
    {
        $report->update(['status' => 'rejected']);
        return back()->with('success', 'Friction report rejected.');
    }

    public function createPoll(Request $request, FrictionReport $report)
    {
        $validated = $request->validate([
            'starts_at' => 'required|date',
            'ends_at' => 'required|date|after:starts_at',
            'min_votes' => 'nullable|integer|min:1',
        ]);

        Poll::create([
            'friction_report_id' => $report->id,
            'starts_at' => $validated['starts_at'],
            'ends_at' => $validated['ends_at'],
            'min_votes' => $validated['min_votes'] ?? null,
            'status' => 'active',
        ]);

        return back()->with('success', 'Poll created successfully!');
    }

    public function closePoll(Poll $poll)
    {
        // Calculate winner using ranked-choice voting (simplified)
        $proposals = RootProposal::where('friction_report_id', $poll->friction_report_id)->get();
        
        $scores = [];
        foreach ($proposals as $proposal) {
            $scores[$proposal->id] = 0;
            
            // Simple scoring: 3 points for 1st rank, 2 for 2nd, 1 for 3rd
            $firstRankVotes = PollVote::where('poll_id', $poll->id)
                ->where('root_proposal_id', $proposal->id)
                ->where('rank', 1)
                ->count();
            
            $secondRankVotes = PollVote::where('poll_id', $poll->id)
                ->where('root_proposal_id', $proposal->id)
                ->where('rank', 2)
                ->count();
            
            $thirdRankVotes = PollVote::where('poll_id', $poll->id)
                ->where('root_proposal_id', $proposal->id)
                ->where('rank', 3)
                ->count();
            
            $scores[$proposal->id] = ($firstRankVotes * 3) + ($secondRankVotes * 2) + ($thirdRankVotes * 1);
        }

        arsort($scores);
        $winningProposalId = array_key_first($scores);

        if ($winningProposalId) {
            $winningProposal = RootProposal::find($winningProposalId);
            $totalVotes = PollVote::where('poll_id', $poll->id)->distinct('user_id')->count();
            $firstRankVotes = PollVote::where('poll_id', $poll->id)
                ->where('root_proposal_id', $winningProposalId)
                ->where('rank', 1)
                ->count();
            
            $votePercentage = $totalVotes > 0 ? round(($firstRankVotes / $totalVotes) * 100) : 0;

            // Create dictionary entry
            DictionaryEntry::create([
                'root' => $winningProposal->proposed_root,
                'definition' => $poll->frictionReport->description,
                'examples' => $poll->frictionReport->examples,
                'status' => 'provisional',
                'canonized_at' => now(),
                'coined_by' => $winningProposal->user_id,
                'vote_percentage' => $votePercentage,
            ]);

            $poll->update([
                'status' => 'closed',
                'winning_proposal_id' => $winningProposalId,
            ]);

            $poll->frictionReport->update(['status' => 'completed']);

            return back()->with('success', 'Poll closed and winning root added to dictionary!');
        }

        return back()->withErrors(['error' => 'No votes found for this poll.']);
    }

    public function createSection(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'slug' => 'required|string|max:255|unique:forum_sections,slug',
            'description' => 'nullable|string',
            'order' => 'required|integer',
        ]);

        ForumSection::create($validated);

        return back()->with('success', 'Forum section created successfully!');
    }

    public function deletePost(ForumPost $post)
    {
        $post->delete();
        return back()->with('success', 'Post deleted successfully!');
    }
}

?>