<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ForumSection extends Model
{
    protected $fillable = [
        'name',
        'slug',
        'description',
        'order',
    ];

    public function posts()
    {
        return $this->hasMany(ForumPost::class, 'section_id');
    }
}