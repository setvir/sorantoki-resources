<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Poll extends Model
{
    protected $fillable = [
        'friction_report_id',
        'starts_at',
        'ends_at',
        'min_votes',
        'status',
        'winning_proposal_id',
    ];

    protected function casts(): array
    {
        return [
            'starts_at' => 'datetime',
            'ends_at' => 'datetime',
        ];
    }

    public function frictionReport()
    {
        return $this->belongsTo(FrictionReport::class);
    }

    public function winningProposal()
    {
        return $this->belongsTo(RootProposal::class, 'winning_proposal_id');
    }

    public function votes()
    {
        return $this->hasMany(PollVote::class);
    }

    public function isActive()
    {
        return $this->status === 'active' && 
               now()->between($this->starts_at, $this->ends_at);
    }

    public function shouldClose()
    {
        if ($this->min_votes && $this->votes()->distinct('user_id')->count() >= $this->min_votes) {
            return true;
        }
        return now()->greaterThan($this->ends_at);
    }
}