<?php
namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use Notifiable;

    protected $fillable = [
        'name',
        'email',
        'password',
        'role',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }

    public function isAdmin()
    {
        return $this->role === 'admin';
    }

    public function dictionaryEntries()
    {
        return $this->hasMany(DictionaryEntry::class, 'coined_by');
    }

    public function frictionReports()
    {
        return $this->hasMany(FrictionReport::class);
    }

    public function rootProposals()
    {
        return $this->hasMany(RootProposal::class);
    }

    public function pollVotes()
    {
        return $this->hasMany(PollVote::class);
    }

    public function forumPosts()
    {
        return $this->hasMany(ForumPost::class);
    }

    public function forumComments()
    {
        return $this->hasMany(ForumComment::class);
    }
}