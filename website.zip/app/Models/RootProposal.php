<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RootProposal extends Model
{
    protected $fillable = [
        'friction_report_id',
        'user_id',
        'proposed_root',
        'justification',
        'sources',
    ];

    public function frictionReport()
    {
        return $this->belongsTo(FrictionReport::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function votes()
    {
        return $this->hasMany(PollVote::class);
    }
}