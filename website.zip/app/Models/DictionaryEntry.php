<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DictionaryEntry extends Model
{
    protected $fillable = [
        'root',
        'definition',
        'word_class',
        'examples',
        'notes',
        'status',
        'canonized_at',
        'coined_by',
        'vote_percentage',
    ];

    protected function casts(): array
    {
        return [
            'canonized_at' => 'datetime',
        ];
    }

    public function coiner()
    {
        return $this->belongsTo(User::class, 'coined_by');
    }

    public function isProvisional()
    {
        return $this->status === 'provisional' && 
               $this->canonized_at && 
               $this->canonized_at->addYears(2)->isFuture();
    }

    public function canBeReplaced()
    {
        return $this->isProvisional();
    }
}