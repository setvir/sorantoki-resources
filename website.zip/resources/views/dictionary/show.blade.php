@extends('layouts.app')

@section('title', $entry->root)

@section('content')
<div class="container">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('dictionary.index') }}">Dictionary</a></li>
                    <li class="breadcrumb-item active">{{ $entry->root }}</li>
                </ol>
            </nav>

            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h2 class="mb-0">{{ $entry->root }}</h2>
                </div>
                <div class="card-body">
                    @if($entry->word_class)
                        <p class="text-muted"><em>{{ $entry->word_class }}</em></p>
                    @endif

                    <h5>Definition</h5>
                    <p>{{ $entry->definition }}</p>

                    @if($entry->examples)
                        <h5 class="mt-4">Examples</h5>
                        <div class="bg-light p-3 rounded">
                            {!! nl2br(e($entry->examples)) !!}
                        </div>
                    @endif

                    @if($entry->notes)
                        <h5 class="mt-4">Notes</h5>
                        <p>{{ $entry->notes }}</p>
                    @endif

                    <hr class="my-4">

                    <div class="row">
                        <div class="col-md-6">
                            <strong>Status:</strong>
                            @if($entry->status === 'canonical')
                                <span class="badge bg-success">Canonical</span>
                            @else
                                <span class="badge bg-warning">Provisional</span>
                            @endif
                        </div>
                        <div class="col-md-6">
                            @if($entry->canonized_at)
                                <strong>Canonized:</strong> {{ $entry->canonized_at->format('M d, Y') }}
                            @endif
                        </div>
                    </div>

                    @if($entry->coined_by)
                        <div class="mt-3">
                            <strong>Coined by:</strong> {{ $entry->coiner->name }}
                            @if($entry->vote_percentage)
                                with {{ $entry->vote_percentage }}% community approval
                            @endif
                        </div>
                    @endif

                    @if($entry->isProvisional())
                        <div class="alert alert-info mt-3">
                            This root is still provisional and can be replaced by community vote within 
                            {{ $entry->canonized_at->addYears(2)->diffForHumans() }}.
                        </div>
                    @endif
                </div>
            </div>

            <div class="mt-3">
                <a href="{{ route('dictionary.index') }}" class="btn btn-secondary">Back to Dictionary</a>
            </div>
        </div>
    </div>
</div>
@endsection