@extends('layouts.app')

@section('title', 'Dictionary')

@section('content')
<div class="container">
    <div class="row mb-4">
        <div class="col-md-8">
            <h1>Sorantoki Dictionary</h1>
            <p class="text-muted">Browse {{ $entries->total() }} roots</p>
        </div>
        <div class="col-md-4">
            <form action="{{ route('dictionary.search') }}" method="GET">
                <div class="input-group">
                    <input type="text" 
                           name="q" 
                           class="form-control" 
                           placeholder="Search roots or definitions..." 
                           value="{{ $query ?? '' }}">
                    <button class="btn btn-primary" type="submit">
                        <i class="bi bi-search"></i> Search
                    </button>
                </div>
            </form>
        </div>
    </div>

    @if(isset($query))
        <div class="alert alert-info">
            Showing results for: <strong>{{ $query }}</strong>
            <a href="{{ route('dictionary.index') }}" class="float-end">Clear search</a>
        </div>
    @endif

    <div class="row">
        @forelse($entries as $entry)
            <div class="col-md-6 mb-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">
                            <a href="{{ route('dictionary.show', $entry) }}" class="text-decoration-none">
                                {{ $entry->root }}
                            </a>
                            @if($entry->status === 'canonical')
                                <span class="badge bg-success" style="float:right">Canonical</span>
                            @else
                                <span class="badge bg-warning" style="float:right">Provisional</span>
                            @endif
                        </h5>
                        @if($entry->word_class)
                            <p class="text-muted small mb-1">{{ $entry->word_class }}</p>
                        @endif
                        <p class="card-text">{{ Str::limit($entry->definition, 100) }}</p>
                        @if($entry->coined_by)
                            <p class="small text-muted mb-0">
                                Coined by: {{ $entry->coiner->name }}
                                @if($entry->vote_percentage)
                                    ({{ $entry->vote_percentage }}% approval)
                                @endif
                            </p>
                        @endif
                    </div>
                </div>
            </div>
        @empty
            <div class="col-12">
                <div class="alert alert-warning">
                    No entries found. @if(isset($query)) Try a different search. @endif
                </div>
            </div>
        @endforelse
    </div>

    <div class="mt-4">
        {{ $entries->links() }}
    </div>
</div>
@endsection