@extends('layouts.app')

@section('title', 'Poll: ' . $poll->frictionReport->concept)

@section('content')
<div class="container">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('polls.index') }}">Polls</a></li>
                    <li class="breadcrumb-item active">{{ $poll->frictionReport->concept }}</li>
                </ol>
            </nav>

            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h3 class="mb-0">{{ $poll->frictionReport->concept }}</h3>
                </div>
                <div class="card-body">
                    <p class="lead">{{ $poll->frictionReport->description }}</p>
                    
                    @if($poll->frictionReport->examples)
                        <div class="alert alert-light">
                            <strong>Examples:</strong><br>
                            {!! nl2br(e($poll->frictionReport->examples)) !!}
                        </div>
                    @endif

                    <div class="row mt-3">
                        <div class="col-md-6">
                            <p class="mb-0"><strong>Poll ends:</strong> {{ $poll->ends_at->format('M d, Y g:i A') }}</p>
                            <p class="text-muted small">{{ $poll->ends_at->diffForHumans() }}</p>
                        </div>
                        <div class="col-md-6">
                            <p class="mb-0"><strong>Total votes:</strong> {{ $poll->votes()->distinct('user_id')->count() }}</p>
                            @if($poll->min_votes)
                                <p class="text-muted small">Minimum {{ $poll->min_votes }} votes required</p>
                            @endif
                        </div>
                    </div>
                </div>
            </div>

            <h4>Root Proposals</h4>

            @if($userVotes)
                <div class="alert alert-success">
                    ✓ You have already voted in this poll. You can change your vote below.
                </div>
            @endif

            <form action="{{ route('polls.vote', $poll) }}" method="POST" id="voteForm">
                @csrf
                <div id="proposalsList">
                    @foreach($poll->frictionReport->proposals as $proposal)
                        <div class="card mb-3 proposal-card" data-proposal-id="{{ $proposal->id }}">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div class="flex-grow-1">
                                        <h5 class="card-title">{{ $proposal->proposed_root }}</h5>
                                        
                                        @if($proposal->justification)
                                            <p class="card-text">{{ $proposal->justification }}</p>
                                        @endif

                                        @if($proposal->sources)
                                            <p class="small text-muted">
                                                <strong>Sources:</strong> {{ $proposal->sources }}
                                            </p>
                                        @endif

                                        <p class="small text-muted mb-0">
                                            Proposed by {{ $proposal->user->name }}
                                        </p>
                                    </div>

                                    <div class="ms-3">
                                        <select class="form-select rank-select" name="rankings[{{ $proposal->id }}]">
                                            <option value="">Not ranked</option>
                                            <option value="1" {{ isset($userVotes[1]) && $userVotes[1] == $proposal->id ? 'selected' : '' }}>1st choice</option>
                                            <option value="2" {{ isset($userVotes[2]) && $userVotes[2] == $proposal->id ? 'selected' : '' }}>2nd choice</option>
                                            <option value="3" {{ isset($userVotes[3]) && $userVotes[3] == $proposal->id ? 'selected' : '' }}>3rd choice</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach

                    <div class="card mb-3">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h5 class="card-title mb-0">None of the above</h5>
                                    <p class="small text-muted mb-0">Reject all proposals</p>
                                </div>
                                <div>
                                    <select class="form-select rank-select" name="rankings[0]">
                                        <option value="">Not ranked</option>
                                        <option value="1">1st choice</option>
                                        <option value="2">2nd choice</option>
                                        <option value="3">3rd choice</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary btn-lg">Submit Vote</button>
                    <a href="{{ route('polls.index') }}" class="btn btn-secondary">Back to Polls</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const selects = document.querySelectorAll('.rank-select');
    
    selects.forEach(select => {
        select.addEventListener('change', function() {
            validateRankings();
        });
    });
    
    function validateRankings() {
        const selectedRanks = {};
        selects.forEach(select => {
            const value = select.value;
            if (value) {
                if (selectedRanks[value]) {
                    // Duplicate rank found
                    select.classList.add('is-invalid');
                } else {
                    selectedRanks[value] = true;
                    select.classList.remove('is-invalid');
                }
            } else {
                select.classList.remove('is-invalid');
            }
        });
    }
});
</script>
@endsection