@extends('layouts.app')

@section('title', 'Active Polls')

@section('content')
<div class="container">
    <h1 class="mb-4">Active Polls</h1>

    <div class="alert alert-info">
        <strong>Ranked-Choice Voting:</strong> Rank the proposals in order of preference. 
        Your first choice gets the most weight, followed by your second and third choices.
    </div>

    @forelse($activePolls as $poll)
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">{{ $poll->frictionReport->concept }}</h5>
            </div>
            <div class="card-body">
                <p>{{ $poll->frictionReport->description }}</p>
                
                <div class="row mt-3">
                    <div class="col-md-6">
                        <small class="text-muted">
                            <strong>Ends:</strong> {{ $poll->ends_at->format('M d, Y g:i A') }}
                            ({{ $poll->ends_at->diffForHumans() }})
                        </small>
                    </div>
                    <div class="col-md-6 text-end">
                        <small class="text-muted">
                            <strong>Votes:</strong> {{ $poll->votes()->distinct('user_id')->count() }}
                            @if($poll->min_votes)
                                / {{ $poll->min_votes }} required
                            @endif
                        </small>
                    </div>
                </div>

                <a href="{{ route('polls.show', $poll) }}" class="btn btn-primary mt-3">
                    View & Vote
                </a>
            </div>
        </div>
    @empty
        <div class="alert alert-warning">
            No active polls at the moment. Check back later!
        </div>
    @endforelse
</div>
@endsection