@extends('layouts.app')

@section('title', 'Home')

@section('content')
<div class="container">
    <div class="jumbotron bg-light p-5 rounded-3 mb-4">
        <h1 class="display-4">Welcome to Sorantoki</h1>
        <p class="lead">A constructed language designed for clarity, ease of learning, and community-driven growth.</p>
        <hr class="my-4">
        <p>Explore our grammar, search the dictionary, and help shape the language through community voting.</p>
        <a class="btn btn-primary btn-lg" href="{{ route('grammar') }}" role="button">Learn the Grammar</a>
        <a class="btn btn-outline-primary btn-lg" href="{{ route('dictionary.index') }}" role="button">Browse Dictionary</a>
    </div>

    <div class="row g-4">
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h3 class="text-primary">{{ $stats['total_roots'] }}</h3>
                    <p class="text-muted mb-0">Total Roots</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h3 class="text-success">{{ $stats['canonical_roots'] }}</h3>
                    <p class="text-muted mb-0">Canonical Roots</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h3 class="text-warning">{{ $stats['active_polls'] }}</h3>
                    <p class="text-muted mb-0">Active Polls</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h3 class="text-info">{{ $stats['pending_reports'] }}</h3>
                    <p class="text-muted mb-0">Pending Reports</p>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-5">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">About Sorantoki</h5>
                </div>
                <div class="card-body">
                    <p>Sorantoki uses a TAM (tense, aspect, mood) serial verb system to provide full grammatical functionality without complex inflections.</p>
                    <p>Key features:</p>
                    <ul>
                        <li>Simple phonology: 10 consonants, 5 vowels</li>
                        <li>Strict SVO word order</li>
                        <li>No irregular verbs</li>
                        <li>Community-driven lexicon growth</li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0">How to Contribute</h5>
                </div>
                <div class="card-body">
                    <ol>
                        <li><strong>Submit Friction Reports:</strong> Identify concepts that need new words</li>
                        <li><strong>Propose Roots:</strong> Suggest phonotactically valid roots for concepts</li>
                        <li><strong>Vote on Polls:</strong> Help decide which roots become canonical</li>
                        <li><strong>Join Discussions:</strong> Participate in forum conversations</li>
                    </ol>
                    @guest
                        <a href="{{ route('register') }}" class="btn btn-success">Join Now</a>
                    @endguest
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-5">
        <div class="card-header">
            <h5 class="mb-0">Lexicon Growth Protocol</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <h6 class="text-primary">📝 Friction Report (Anytime)</h6>
                    <p class="small">Submit needs for new words with examples. Community upvotes if they agree.</p>

                    <h6 class="text-primary mt-3">🗓️ Weekly Selection (Sunday)</h6>
                    <p class="small">Curators pick 3-5 highest-friction concepts to move forward.</p>

                    <h6 class="text-primary mt-3">💡 Root Proposals (Mon-Wed)</h6>
                    <p class="small">Anyone can propose up to 3 phonotactically valid roots with sources.</p>
                </div>
                <div class="col-md-6">
                    <h6 class="text-success">🗳️ Poll (Thu-Sat)</h6>
                    <p class="small">Ranked-choice voting with "none of the above" option.</p>

                    <h6 class="text-success mt-3">✨ Canonization (Sunday Night)</h6>
                    <p class="small">Winner instantly added with coiner credit and vote percentage.</p>

                    <h6 class="text-info mt-3">🔒 Lock Period</h6>
                    <p class="small">Root stays provisional for 2 years, then locks unless 90% supermajority replaces it.</p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection