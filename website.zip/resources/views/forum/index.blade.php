@extends('layouts.app')

@section('title', 'Forum')

@section('content')
<div class="container">
    <h1 class="mb-4">Community Forum</h1>

    <div class="row g-4">
        @foreach($sections as $section)
            <div class="col-md-4">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title">
                            <a href="{{ route('forum.section', $section) }}" class="text-decoration-none">
                                {{ $section->name }}
                            </a>
                        </h5>
                        <p class="card-text text-muted">{{ $section->description }}</p>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="badge bg-primary">{{ $section->posts_count }} posts</span>
                            <a href="{{ route('forum.section', $section) }}" class="btn btn-sm btn-outline-primary">
                                Browse →
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        @endforeach
    </div>

    @guest
        <div class="alert alert-info mt-4">
            <a href="{{ route('login') }}">Login</a> or <a href="{{ route('register') }}">register</a> to create posts and join discussions.
        </div>
    @endguest
</div>
@endsection