@extends('layouts.app')

@section('title', $post->title)

@section('content')
<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{ route('forum.index') }}">Forum</a></li>
            <li class="breadcrumb-item"><a href="{{ route('forum.section', $section) }}">{{ $section->name }}</a></li>
            <li class="breadcrumb-item active">{{ Str::limit($post->title, 50) }}</li>
        </ol>
    </nav>

    <div class="card mb-4">
        <div class="card-header">
            <h2 class="mb-0">{{ $post->title }}</h2>
        </div>
        <div class="card-body">
            <div class="mb-3">
                {!! nl2br(e($post->content)) !!}
            </div>
            <hr>
            <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">
                    Posted by <strong>{{ $post->user->name }}</strong> on {{ $post->created_at->format('M d, Y g:i A') }}
                </small>
                @if(auth()->check() && (auth()->user()->isAdmin() || auth()->id() === $post->user_id))
                    <form action="{{ route('admin.forum.post.delete', $post) }}" method="POST" onsubmit="return confirm('Delete this post?')">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                    </form>
                @endif
            </div>
        </div>
    </div>

    <h4 class="mb-3">Comments ({{ $post->comments->count() }})</h4>

    @foreach($post->comments as $comment)
        <div class="card mb-3">
            <div class="card-body">
                <p class="mb-2">{!! nl2br(e($comment->content)) !!}</p>
                <small class="text-muted">
                    {{ $comment->user->name }} • {{ $comment->created_at->diffForHumans() }}
                </small>
            </div>
        </div>
    @endforeach

    @auth
        <div class="card">
            <div class="card-header">Add Comment</div>
            <div class="card-body">
                <form action="{{ route('forum.comment.store', $post) }}" method="POST">
                    @csrf
                    <div class="mb-3">
                        <textarea class="form-control" name="content" rows="3" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Post Comment</button>
                </form>
            </div>
        </div>
    @else
        <div class="alert alert-info">
            <a href="{{ route('login') }}">Login</a> to post a comment.
        </div>
    @endauth
</div>
@endsection