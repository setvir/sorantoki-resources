@extends('layouts.app')

@section('title', $section->name)

@section('content')
<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{ route('forum.index') }}">Forum</a></li>
            <li class="breadcrumb-item active">{{ $section->name }}</li>
        </ol>
    </nav>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1>{{ $section->name }}</h1>
            <p class="text-muted">{{ $section->description }}</p>
        </div>
        @auth
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#newPostModal">
                New Post
            </button>
        @endauth
    </div>

    @forelse($posts as $post)
        <div class="card mb-3">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <h5 class="card-title">
                        <a href="{{ route('forum.post.show', [$section, $post]) }}" class="text-decoration-none">
                            @if($post->is_pinned) 📌 @endif
                            {{ $post->title }}
                        </a>
                    </h5>
                    <span class="badge bg-secondary">{{ $post->comments->count() }} comments</span>
                </div>
                <p class="card-text">{{ Str::limit($post->content, 200) }}</p>
                <small class="text-muted">
                    Posted by {{ $post->user->name }} on {{ $post->created_at->format('M d, Y') }}
                </small>
            </div>
        </div>
    @empty
        <div class="alert alert-info">
            No posts yet. Be the first to start a discussion!
        </div>
    @endforelse

    <div class="mt-4">
        {{ $posts->links() }}
    </div>
</div>

@auth
<!-- New Post Modal -->
<div class="modal fade" id="newPostModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">New Post in {{ $section->name }}</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="{{ route('forum.post.store', $section) }}" method="POST">
                @csrf
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="title" class="form-label">Title</label>
                        <input type="text" class="form-control" id="title" name="title" required>
                    </div>
                    <div class="mb-3">
                        <label for="content" class="form-label">Content</label>
                        <textarea class="form-control" id="content" name="content" rows="5" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Post</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endauth
@endsection