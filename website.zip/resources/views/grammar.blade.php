@extends('layouts.app')

@section('title', 'Grammar Reference')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-lg-3">
            <div class="card sticky-top" style="top: 20px;">
                <div class="card-header">
                    <h6 class="mb-0">Table of Contents</h6>
                </div>
                <div class="card-body">
                    <nav class="nav flex-column small">
                        <a class="nav-link" href="#preface">Preface</a>
                        <a class="nav-link" href="#phonology">1. Phonology & Orthography</a>
                        <a class="nav-link" href="#principles">2. Core Principles</a>
                        <a class="nav-link" href="#pronouns">3. Pronouns & Plurals</a>
                        <a class="nav-link" href="#nouns">4. Noun Phrases</a>
                        <a class="nav-link" href="#possession">5. Possession</a>
                        <a class="nav-link" href="#plural-marker">6. Definite Plural Marker</a>
                        <a class="nav-link" href="#tam">7. TAM Serial Verb Template</a>
                        <a class="nav-link" href="#stative">8. Stative/Adjectival Predicates</a>
                        <a class="nav-link" href="#passive">9. Passive / Resultative</a>
                        <a class="nav-link" href="#questions">10. Questions</a>
                        <a class="nav-link" href="#comparison">11. Comparison</a>
                        <a class="nav-link" href="#relative">12. Relative Clauses</a>
                        <a class="nav-link" href="#prepositions">13. Prepositions</a>
                        <a class="nav-link" href="#particles">14. Additional Particles</a>
                        <a class="nav-link" href="#derivation">15. Derivational Morphology</a>
                        <a class="nav-link" href="#reflexives">16. Reflexives & Reciprocals</a>
                        <a class="nav-link" href="#numbers">17. Numbers</a>
                        <a class="nav-link" href="#punctuation">18. Punctuation & Capitalisation</a>
                        <a class="nav-link" href="#imperatives">19. Imperatives</a>
                        <a class="nav-link" href="#existential">20. Existential / Locative</a>
                        <a class="nav-link" href="#full-example">21. Full Example</a>
                    </nav>
                </div>
            </div>
        </div>

        <div class="col-lg-9">
            <h1 class="mb-4">Sorantoki Grammar Reference</h1>

            <div class="alert alert-info">
                <strong>Note:</strong> This is an abbreviated reference. For the complete grammar guide, 
                <a href="{{ asset('grammar/sorantoki-full.pdf') }}" class="alert-link">download the PDF</a>.
            </div>

            <!-- Preface -->
            <section id="preface" class="mb-5">
                <h2>Preface</h2>
                <p>Sorantoki is a simple, clear, and friendly auxiliary language designed to make communication easy for everyone. It sits in the middle of the auxlang spectrum: more regular and logical than natural languages, but more natural and intuitive than highly engineered or philosophical languages. Its goal is not perfection on paper, but ease of learning and ease of use in real conversations.</p>
                
                <p>The language has a single fixed word order (SVO), a very small sound system, and a completely regular grammar with no exceptions. Instead of verb conjugations or complicated endings, Sorantoki uses a straight-line chain of small helper words to express tense, aspect, mood, and other meanings. This makes sentences easy to build and even easier to understand.</p>

                <h4>Your First Word</h4>
                <div class="card bg-light">
                    <div class="card-body">
                        <h5 class="card-title">wasa</h5>
                        <p class="card-text">pronounced <em>wasa, vasa, watha,</em> or <em>vatha</em> — means "I didn't catch that" or "The message wasn't received clearly." It can refer to unclear hearing, unclear speech, or simply unclear understanding.</p>
                        <p class="card-text"><strong>wasa</strong> is a gentle, non-blaming way to ask someone to repeat, slow down, or clarify. It signals cooperation, not error. In Sorantoki culture, communication is shared responsibility: if something isn't understood, the listener uses <em>wasa</em> without hesitation, and the speaker repeats without feeling corrected.</p>
                    </div>
                </div>
            </section>

            <!-- 1. PHONOLOGY -->
            <section id="phonology" class="mb-5">
                <h2>1. Phonology and Orthography</h2>
                
                <h4>Consonants</h4>
                <p>Sorantoki has ten consonants: <strong>p, t, k, f, m, n, s, w, y, r</strong></p>
                <ul>
                    <li><strong>p, t, k, f, m, n</strong> — like English</li>
                    <li><strong>s</strong> — like English "see"; th (lisped s) is also fully correct</li>
                    <li><strong>w</strong> — [w] or [v] (both fully correct)</li>
                    <li><strong>y</strong> — like English "yes"</li>
                    <li><strong>r</strong> — may be [r], [ɾ], or [l]</li>
                </ul>
                <p class="small text-muted">Note: Variants are fully correct, do not change meaning, and belong to the single standard form. Speakers choose whichever variant is natural for them.</p>

                <h4>Vowels</h4>
                <p><strong>a, e, i, o, u</strong></p>

                <h4>Diphthongs</h4>
                <p>ai, au, ei, oi, ou</p>

                <h4>Syllable Structure</h4>
                <p>(C)V|D(N) where N = m or n, D = Diphthong</p>
                <ul>
                    <li>Allowed codas: m, n only</li>
                    <li>No consonant clusters</li>
                </ul>

                <h4>Stress</h4>
                <p>Stress always falls on the <strong>penultimate syllable</strong> of the whole word.</p>
                <ul>
                    <li>Prefixes (noi-, pe-) count normally → they can shift stress rightward</li>
                    <li>Suffixes (-n, -in, -ri, -ta, -pa, -ru, -ti, -ka) and plural marker are "invisible" to stress</li>
                </ul>
            </section>

            <!-- 2. PRINCIPLES -->
            <section id="principles" class="mb-5">
                <h2>2. Core Principles</h2>
                <ul>
                    <li><strong>Word Order:</strong> Strict SVO (Subject-Verb-Object)</li>
                    <li><strong>Modifiers:</strong> Always precede the head (including possessives and adverbs)</li>
                    <li><strong>No Copula:</strong> "mi tokoto" = "I am a doctor"</li>
                    <li><strong>Word-Class Flexibility:</strong> Any adjective → verb automatically ("be Adj")</li>
                </ul>

                <h4>Sentence Structure</h4>
                <p>Subject → (Adverbs/Time/Place) → [TAM Chain] → (si/kuno) → Direct Object → (Prepositional phrases)</p>
            </section>

            <!-- 3. PRONOUNS & PLURALS -->
            <section id="pronouns" class="mb-5">
                <h2>3. Pronouns & Plurals</h2>

                <h4>Personal Pronouns</h4>
                <table class="table table-bordered table-sm w-auto">
                    <thead class="table-light">
                        <tr>
                            <th>Person</th><th>Singular</th><th>Plural</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr><td>1st</td><td>mi</td><td>min</td></tr>
                        <tr><td>2nd</td><td>tu</td><td>tun</td></tr>
                        <tr><td>3rd</td><td>ta</td><td>tan</td></tr>
                    </tbody>
                </table>
                <p class="small text-muted">Pronouns use -n suffix for plural and are an exception to the definite plural marker rule.</p>

                <h4>Plural Marker</h4>
                <p>The general plural marker is <strong>-ta</strong>.</p>
                <ul>
                    <li><strong>sona</strong> → <strong>sonata</strong> = person → people</li>
                    <li><strong>kata-ta</strong> = words</li>
                </ul>
            </section>

            <!-- 4. NOUN PHRASES -->
            <section id="nouns" class="mb-5">
                <h2>4. Noun Phrases</h2>

                <p>Modifiers always come before the noun:</p>
                <ul>
                    <li><strong>tai sona</strong> = big person</li>
                    <li><strong>wena kata</strong> = good word</li>
                    <li><strong>nira tomo</strong> = small house</li>
                </ul>

                <h4>Structure</h4>
                <p><strong>(Demonstrative) + (Number) + (Modifiers...) + NOUN + (Plural -n/-in, if specific)</strong></p>

                <h4>Demonstratives</h4>
                <ul>
                    <li><strong>ko</strong> = this / these (near speaker)</li>
                    <li><strong>so</strong> = that / those (far or previous)</li>
                </ul>

                <p>Examples:</p>
                <ul>
                    <li><strong>ko tai kasa</strong> = this big house</li>
                    <li><strong>so pukan</strong> = those books (specific)</li>
                </ul>
            </section>

            <!-- 5. POSSESSION -->
            <section id="possession" class="mb-5">
                <h2>5. Possession</h2>

                <p>Possession is marked with <strong>te</strong> between possessor and possessed:</p>
                <h4>Structure</h4>
                <p><strong>Possessor + te + Possessed</strong></p>

                <h4>Examples</h4>
                <ul>
                    <li><strong>mi te tomo</strong> = my house</li>
                    <li><strong>ta te kata</strong> = their word</li>
                    <li><strong>sona te paku</strong> = person's bag</li>
                </ul>

                <h4>Colloquial Variant</h4>
                <p>In casual speech, <strong>te</strong> may be dropped with pronouns, body parts, and kinship:</p>
                <ul>
                    <li><strong>mi kasa</strong> = my house (colloquial)</li>
                    <li><strong>mi moran</strong> = my mouth (very common)</li>
                </ul>
                <p class="small text-muted">Forms with te remain the unambiguous standard and are recommended for learners.</p>
            </section>

            <!-- 6. DEFINITE PLURAL MARKER -->
            <section id="plural-marker" class="mb-5">
                <h2>6. The Definite Plural Marker -n / -in</h2>

                <p>Sorantoki has no indefinite plural. Bare nouns are used for generics:</p>
                <ul>
                    <li><strong>kasa</strong> = house / houses (in general)</li>
                    <li><strong>mi peron kasa</strong> = I like houses (any houses)</li>
                </ul>

                <p>The suffix <strong>-n</strong> (after consonant) or <strong>-in</strong> (after vowel or stem-final n) marks definite/specific plurals:</p>
                <ul>
                    <li><strong>ko tai kasan</strong> = these big houses (specific)</li>
                    <li><strong>so pukan</strong> = those books (specific)</li>
                    <li><strong>tai tinin</strong> = the big ones (using generic tin "thing")</li>
                </ul>
            </section>

            <!-- 7. TAM SERIAL VERB -->
            <section id="tam" class="mb-5">
                <h2>7. The TAM Serial Verb Template</h2>
                <p>The verb phrase uses exactly <strong>six ordered slots</strong>:</p>
                
                <div class="table-responsive">
                    <table class="table table-bordered table-sm">
                        <thead class="table-light">
                            <tr>
                                <th>Slot</th>
                                <th>Name</th>
                                <th>Particles</th>
                                <th>Meaning</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>Tense</td>
                                <td>∅ • ya • wi</td>
                                <td>present / past / future</td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>Aspect</td>
                                <td>∅ • in • pa • sa</td>
                                <td>simple / progressive / perfect / habitual</td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td>Negation</td>
                                <td>∅ • no</td>
                                <td>affirmative / negative</td>
                            </tr>
                            <tr>
                                <td>4</td>
                                <td>Modal/Phase</td>
                                <td>kan • muso • wan • sita • suto • pin • na</td>
                                <td>can / must / want / start / stop / finish / imminent</td>
                            </tr>
                            <tr>
                                <td>5</td>
                                <td>Direction</td>
                                <td>∅ • to • ku • ki • po</td>
                                <td>go / come / benefactive / purpose</td>
                            </tr>
                            <tr>
                                <td>6</td>
                                <td>Main verb</td>
                                <td>(any verb)</td>
                                <td>The real action</td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <h4>Quick Reference</h4>
                <p class="font-monospace small">1 Tense (ya/wi/∅) 2 Aspect (in/pa/sa/∅) 3 Neg (no/∅) 4 Modal/Phase (kan/muso/wan/sita/suto/pin/na) 5 Direction (to/ku/ki/po/∅) 6 Main verb</p>

                <h4>Examples</h4>
                <ul>
                    <li><strong>mi ya monya</strong> = I ate</li>
                    <li><strong>mi in monya</strong> = I'm eating</li>
                    <li><strong>mi pa monya</strong> = I have eaten</li>
                    <li><strong>mi wi no ku</strong> = I will not come</li>
                    <li><strong>mi wan sita monya</strong> = I want to start eating</li>
                    <li><strong>min wi no kan ki mon tun</strong> = We will not be able to give money to you (pl.)</li>
                </ul>

                <h4>Directionals</h4>
                <ul>
                    <li><strong>to + Verb</strong> = go and do (physical motion)</li>
                    <li><strong>ku + Verb</strong> = come and do (motion toward speaker)</li>
                    <li><strong>ki + Verb</strong> = benefactive (to/for someone)</li>
                    <li><strong>po + Verb</strong> = purpose (in order to)</li>
                </ul>
            </section>

            <!-- 8. STATIVE / ADJECTIVAL PREDICATES -->
            <section id="stative" class="mb-5">
                <h2>8. Stative / Adjectival Predicates</h2>

                <h4>Zero Copula (default)</h4>
                <ul>
                    <li><strong>kasa tai</strong> = The house is big</li>
                    <li><strong>mi tokoto</strong> = I am a doctor</li>
                </ul>

                <h4>Optional Emphasis: es</h4>
                <p><strong>es</strong> is an optional emphatic particle ("really is"): <strong>mi es tokoto!</strong> = I really am a doctor!</p>

                <h4>Becoming / Turning X</h4>
                <p><strong>sita + stative</strong> = "become X, get X": <strong>kasa sita tai</strong> = The house becomes big</p>
            </section>

            <!-- 9. PASSIVE / RESULTATIVE -->
            <section id="passive" class="mb-5">
                <h2>9. Passive / Resultative</h2>

                <h4>Prefix pe- on Main Verb</h4>
                <ul>
                    <li><strong>puka pewita</strong> = The book was seen</li>
                    <li><strong>kasa peturan</strong> = The house was built</li>
                </ul>

                <h4>Passive Agent Marking</h4>
                <p>Passive agents are marked by <strong>kon</strong>:</p>
                <ul>
                    <li><strong>puka pewita kon mi</strong> = the book was seen by me</li>
                    <li><strong>kasa peturan kon seroru</strong> = the house was built by the teacher</li>
                </ul>
            </section>

            <!-- 10. QUESTIONS -->
            <section id="questions" class="mb-5">
                <h2>10. Questions</h2>

                <h4>Polar Questions (yes/no)</h4>
                <p>Formed with the particle <strong>ka</strong> at the end:</p>
                <p><strong>mi monya ka?</strong> = Do I eat?</p>
                <p class="small">Yes/No answers normally repeat the verb: <strong>Pon ka?</strong> → <strong>Pon.</strong> / <strong>No pon.</strong></p>

                <h4>WH-Questions</h4>
                <table class="table table-bordered table-sm w-auto">
                    <thead class="table-light">
                        <tr><th>Function</th><th>Word</th></tr>
                    </thead>
                    <tbody>
                        <tr><td>what</td><td>ke</td></tr>
                        <tr><td>which</td><td>ki</td></tr>
                        <tr><td>who</td><td>ye</td></tr>
                        <tr><td>where</td><td>we</td></tr>
                        <tr><td>when</td><td>wen</td></tr>
                        <tr><td>why</td><td>waya</td></tr>
                        <tr><td>how</td><td>moto</td></tr>
                        <tr><td>how many/much</td><td>kanto</td></tr>
                    </tbody>
                </table>

                <p>Structure: <strong>WH + SVO</strong></p>
                <ul>
                    <li><strong>ke tu monya?</strong> = What are you eating?</li>
                    <li><strong>we ta to ki?</strong> = Where is he going?</li>
                    <li><strong>waya mi no monya?</strong> = Why am I not eating?</li>
                </ul>
            </section>

            <!-- 11. COMPARISON -->
            <section id="comparison" class="mb-5">
                <h2>11. Comparison</h2>

                <h4>More Than</h4>
                <p>Use <strong>maso ... pase ...</strong>:</p>
                <p><strong>ta maso pon pase mi</strong> = She is better than me</p>

                <h4>Most</h4>
                <p>Use <strong>se moso</strong> (se is optional definite article):</p>
                <p><strong>ta se moso pon</strong> = She is the best</p>

                <h4>As ... As ...</h4>
                <p>Use <strong>sama ... sama</strong>:</p>
                <p><strong>ta pon sama mi sama</strong> = She is as good as I am</p>
            </section>

            <!-- 12. RELATIVE CLAUSES -->
            <section id="relative" class="mb-5">
                <h2>12. Relative Clauses</h2>

                <p>Marked with <strong>su</strong>:</p>
                <h4>Structure</h4>
                <p><strong>Noun + su + clause</strong></p>

                <h4>Examples</h4>
                <ul>
                    <li><strong>yan su mi wita</strong> = the person who I saw</li>
                    <li><strong>puka su mi wita</strong> = the book that I saw</li>
                    <li><strong>kasa su ta peturan</strong> = the house that they built</li>
                </ul>

                <h4>Resumptive Pronouns (optional)</h4>
                <p>For clarity in complex clauses, a resumptive pronoun may be added:</p>
                <ul>
                    <li><strong>yan su mi toki kon ta</strong> = the person I'm speaking with (optional: ...with him/her)</li>
                </ul>
            </section>

            <!-- 13. PREPOSITIONS -->
            <section id="prepositions" class="mb-5">
                <h2>13. Prepositions</h2>
                <p>Only five true prepositions exist:</p>
                <table class="table table-bordered table-sm">
                    <thead class="table-light">
                        <tr><th>Preposition</th><th>Meaning</th></tr>
                    </thead>
                    <tbody>
                        <tr><td>in</td><td>in / at / on (static location or time)</td></tr>
                        <tr><td>kon</td><td>with (comitative) / by (instrument or passive agent)</td></tr>
                        <tr><td>te</td><td>of / from / possessive / material / partitive</td></tr>
                        <tr><td>kausa</td><td>because of / due to</td></tr>
                        <tr><td>karo</td><td>if (conditional clause introducer)</td></tr>
                    </tbody>
                </table>
            </section>

            <!-- 14. ADDITIONAL PARTICLES -->
            <section id="particles" class="mb-5">
                <h2>14. Additional Particles</h2>
                <table class="table table-bordered table-sm">
                    <thead class="table-light">
                        <tr><th>Particle</th><th>Use</th><th>Placement</th><th>Example</th></tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>se</strong></td>
                            <td>optional definite article</td>
                            <td>before noun/adjective</td>
                            <td>ko kasa se moso tai = this biggest house</td>
                        </tr>
                        <tr>
                            <td><strong>es</strong></td>
                            <td>emphatic/existential copula</td>
                            <td>after subject, before predicate</td>
                            <td>puka es in kasa = there is a book in the house</td>
                        </tr>
                        <tr>
                            <td><strong>e</strong></td>
                            <td>and (coordinates)</td>
                            <td>medial conjunction</td>
                            <td>mi peron puka e mon = I like books and money</td>
                        </tr>
                        <tr>
                            <td><strong>o</strong></td>
                            <td>or (coordinates)</td>
                            <td>medial conjunction</td>
                            <td>tu wan monya o nesi? = do you want to eat or sleep?</td>
                        </tr>
                    </tbody>
                </table>
            </section>

            <!-- 15. DERIVATIONAL MORPHOLOGY -->
            <section id="derivation" class="mb-5">
                <h2>15. Derivational Morphology</h2>

                <h4>Prefix: noi- (Opposite/Absence)</h4>
                <p><strong>noi-</strong> (becomes <strong>noin-</strong> before vowels) forms logical opposites:</p>
                <ul>
                    <li><strong>pon</strong> → <strong>noipon</strong> = good → un-good/badish</li>
                    <li><strong>tai</strong> → <strong>noitai</strong> = big → un-big/smallish</li>
                    <li><strong>es</strong> → <strong>noin-es</strong> = exist → nonexistent</li>
                </ul>

                <h4>Derivational Suffixes</h4>
                <table class="table table-bordered table-sm w-auto">
                    <thead class="table-light">
                        <tr><th>Suffix</th><th>Function</th><th>Example</th></tr>
                    </thead>
                    <tbody>
                        <tr><td>-ri</td><td>manner adverb</td><td>pon → ponri (well)</td></tr>
                        <tr><td>-ta</td><td>abstract noun</td><td>pon → ponta (goodness)</td></tr>
                        <tr><td>-pa</td><td>action noun</td><td>toki → tokipa (speech)</td></tr>
                        <tr><td>-ru</td><td>agent/professional</td><td>sero → seroru (teacher)</td></tr>
                        <tr><td>-ti</td><td>patient/result noun</td><td>sero → seroti (lesson)</td></tr>
                        <tr><td>-ka</td><td>instrument</td><td>toki → tokika (tool for speaking)</td></tr>
                    </tbody>
                </table>
            </section>

            <!-- 16. REFLEXIVES & RECIPROCALS -->
            <section id="reflexives" class="mb-5">
                <h2>16. Reflexives & Reciprocals</h2>

                <h4>Reflexive: si</h4>
                <p>Particle <strong>si</strong> marks that object equals subject:</p>
                <ul>
                    <li><strong>mi wita si</strong> = I see myself</li>
                    <li><strong>ta puku si</strong> = He hit himself</li>
                    <li><strong>mi ya ki mon si</strong> = I gave myself money</li>
                </ul>

                <h4>Reciprocal: kuno</h4>
                <p>Particle <strong>kuno</strong> marks mutual action (subject must be plural):</p>
                <ul>
                    <li><strong>min wita kuno</strong> = We see each other</li>
                    <li><strong>tan ya toki kuno</strong> = They spoke to each other</li>
                    <li><strong>mi e tu wi pokan kuno</strong> = You and I will help each other</li>
                </ul>
            </section>

            <!-- 17. NUMBERS -->
            <section id="numbers" class="mb-5">
                <h2>17. Numbers</h2>
                <div class="row">
                    <div class="col-md-6">
                        <h5>Cardinal Numbers</h5>
                        <ul class="list-unstyled">
                            <li>0 = oru</li>
                            <li>1 = uno</li>
                            <li>2 = tau</li>
                            <li>3 = sai</li>
                            <li>4 = pei</li>
                            <li>5 = niro</li>
                            <li>6 = kima</li>
                            <li>7 = tepu</li>
                            <li>8 = naso</li>
                            <li>9 = reko</li>
                            <li>10 = senu</li>
                            <li>11-19 = senu + [1-9] (e.g., senu uno)</li>
                            <li>20-90 = [2-9] + senu (e.g., tau senu)</li>
                            <li>100 = pasan</li>
                            <li>1000 = miran</li>
                        </ul>
                    </div>
                    <div class="col-md-6">
                        <h5>Ordinals</h5>
                        <p>Add <strong>-ma</strong> to the last element:</p>
                        <ul class="list-unstyled">
                            <li>1st = uno-ma</li>
                            <li>2nd = tau-ma</li>
                            <li>3rd = sai-ma</li>
                            <li>10th = senu-ma</li>
                            <li>21st = tau senu uno-ma</li>
                        </ul>
                    </div>
                </div>
            </section>

            <!-- 18. PUNCTUATION -->
            <section id="punctuation" class="mb-5">
                <h2>18. Punctuation & Capitalisation</h2>

                <h4>Capital Letters</h4>
                <ul>
                    <li>All words are lowercase except proper names of specific people, places, cities, countries</li>
                    <li>Example: <strong>Maria ku.</strong> = Maria is coming.</li>
                </ul>

                <h4>Allowed Punctuation</h4>
                <p>Only five marks exist: <strong>. , ! ? " "</strong></p>
                <ul>
                    <li><strong>.</strong> full stop (end of sentence)</li>
                    <li><strong>,</strong> comma (pause, lists, clarity)</li>
                    <li><strong>!</strong> exclamation mark</li>
                    <li><strong>?</strong> question mark</li>
                    <li><strong>" "</strong> quotation marks</li>
                </ul>

                <h4>Direct Speech</h4>
                <p><strong>ta toki "mi moron tu"</strong> = She said "I love you"</p>
            </section>

            <!-- 19. IMPERATIVES -->
            <section id="imperatives" class="mb-5">
                <h2>19. Imperatives</h2>
                <p>Drop the subject pronoun (2nd person is understood):</p>
                <ul>
                    <li><strong>rapiri monya!</strong> = Eat quickly!</li>
                    <li><strong>no kai!</strong> = Don't fall!</li>
                    <li><strong>to kasa!</strong> = Go home!</li>
                </ul>
                <p>For politeness, add <strong>ko</strong> after the verb:</p>
                <ul>
                    <li><strong>monya ko</strong> = Please eat.</li>
                </ul>
            </section>

            <!-- 20. EXISTENTIAL / LOCATIVE -->
            <section id="existential" class="mb-5">
                <h2>20. Existential / Locative Patterns</h2>
                <p>Pattern <strong>es + location</strong> states existence or location:</p>
                <ul>
                    <li><strong>puka es in kasa</strong> = There is a book in the house / The book is in the house</li>
                    <li><strong>yan es we?</strong> = Where is the person?</li>
                    <li><strong>mon no es te mi</strong> = I have no money (lit. Money does not exist of me)</li>
                </ul>
                
            </section>

            <!-- 21. FULL EXAMPLE -->
            <section id="full-example" class="mb-5">
                <h2>21. Full Example Paragraph</h2>
                <div class="card bg-light">
                    <div class="card-body">
                        <p class="card-text mb-3">
                            <strong>ko tai kasa te min es se moso pon.</strong><br>
                            <strong>so yan su ya ku ki mon tun,</strong><br>
                            <strong>maso tan in no kan ku kausa ruwa.</strong><br>
                            <strong>ye su tun na wita wen kanto ka?</strong><br>
                            <strong>mi wan rapiri pesero po kan toki kon mutan.</strong>
                        </p>
                        <p class="card-text small">
                            <strong>Translation:</strong> This big house of ours is really the best. That person who came wanted to give money to you all, but they could not come because of rain. Who are you all going to see when? I want to be taught quickly in order to speak with everyone.
                        </p>
                    </div>
                </div>
            </section>

            <div class="alert alert-success">
                <h5>Start Learning!</h5>
                <p>Ready to explore more? Check out the <a href="{{ route('dictionary.index') }}" class="alert-link">dictionary</a> or join the <a href="{{ route('forum.index') }}" class="alert-link">forum</a>.</p>
            </div>
        </div>
    </div>
</div>
@endsection