@extends('layouts.app')

@section('title', 'Manage Dictionary')

@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Manage Dictionary</h1>
        <div>
            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addEntryModal">
                Add Entry
            </button>
            <a href="{{ route('admin.dashboard') }}" class="btn btn-secondary">Back to Dashboard</a>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Root</th>
                    <th>Definition</th>
                    <th>Word Class</th>
                    <th>Status</th>
                    <th>Coined By</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach($entries as $entry)
                    <tr>
                        <td><strong>{{ $entry->root }}</strong></td>
                        <td>{{ Str::limit($entry->definition, 50) }}</td>
                        <td>{{ $entry->word_class ?? '-' }}</td>
                        <td>
                            @if($entry->status === 'canonical')
                                <span class="badge bg-success">Canonical</span>
                            @else
                                <span class="badge bg-warning">Provisional</span>
                            @endif
                        </td>
                        <td>{{ $entry->coiner->name ?? '-' }}</td>
                        <td>
                            <button class="btn btn-sm btn-primary" data-bs-toggle="modal" 
                                    data-bs-target="#editModal-{{ $entry->id }}">
                                Edit
                            </button>
                            <form action="{{ route('admin.dictionary.delete', $entry) }}" method="POST" class="d-inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-danger" 
                                        onclick="return confirm('Delete this entry?')">
                                    Delete
                                </button>
                            </form>
                        </td>
                    </tr>

                    <!-- Edit Modal -->
                    <div class="modal fade" id="editModal-{{ $entry->id }}" tabindex="-1">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Edit Entry: {{ $entry->root }}</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <form action="{{ route('admin.dictionary.update', $entry) }}" method="POST">
                                    @csrf
                                    @method('PUT')
                                    <div class="modal-body">
                                        <div class="mb-3">
                                            <label class="form-label">Root</label>
                                            <input type="text" class="form-control" name="root" 
                                                   value="{{ $entry->root }}" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Definition</label>
                                            <textarea class="form-control" name="definition" rows="3" required>{{ $entry->definition }}</textarea>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Word Class</label>
                                            <input type="text" class="form-control" name="word_class" 
                                                   value="{{ $entry->word_class }}">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Examples</label>
                                            <textarea class="form-control" name="examples" rows="3">{{ $entry->examples }}</textarea>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Notes</label>
                                            <textarea class="form-control" name="notes" rows="2">{{ $entry->notes }}</textarea>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Status</label>
                                            <select class="form-select" name="status" required>
                                                <option value="provisional" {{ $entry->status === 'provisional' ? 'selected' : '' }}>
                                                    Provisional
                                                </option>
                                                <option value="canonical" {{ $entry->status === 'canonical' ? 'selected' : '' }}>
                                                    Canonical
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-primary">Save Changes</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                @endforeach
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        {{ $entries->links() }}
    </div>
</div>

<!-- Add Entry Modal -->
<div class="modal fade" id="addEntryModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Dictionary Entry</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="{{ route('admin.dictionary.store') }}" method="POST">
                @csrf
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Root</label>
                        <input type="text" class="form-control" name="root" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Definition</label>
                        <textarea class="form-control" name="definition" rows="3" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Word Class</label>
                        <input type="text" class="form-control" name="word_class" 
                               placeholder="e.g., noun, verb, adjective">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Examples</label>
                        <textarea class="form-control" name="examples" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Notes</label>
                        <textarea class="form-control" name="notes" rows="2"></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select class="form-select" name="status" required>
                            <option value="provisional">Provisional</option>
                            <option value="canonical">Canonical</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Add Entry</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection