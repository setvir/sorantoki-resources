@extends('layouts.app')

@section('title', 'Admin Dashboard')

@section('content')
<div class="container-fluid">
    <h1 class="mb-4">Admin Dashboard</h1>

    <div class="row g-4 mb-4">
        <div class="col-md-3">
            <div class="card border-primary">
                <div class="card-body text-center">
                    <h3 class="text-primary">{{ $stats['total_entries'] }}</h3>
                    <p class="mb-0">Dictionary Entries</p>
                    <a href="{{ route('admin.dictionary') }}" class="btn btn-sm btn-primary mt-2">Manage</a>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-warning">
                <div class="card-body text-center">
                    <h3 class="text-warning">{{ $stats['pending_reports'] }}</h3>
                    <p class="mb-0">Pending Reports</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-info">
                <div class="card-body text-center">
                    <h3 class="text-info">{{ $stats['selected_reports'] }}</h3>
                    <p class="mb-0">Selected Reports</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-success">
                <div class="card-body text-center">
                    <h3 class="text-success">{{ $stats['active_polls'] }}</h3>
                    <p class="mb-0">Active Polls</p>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6">
            <div class="card mb-4">
                <div class="card-header bg-warning text-dark">
                    <h5 class="mb-0">Top Friction Reports (Pending)</h5>
                </div>
                <div class="card-body">
                    @forelse($pendingReports as $report)
                        <div class="border-bottom pb-3 mb-3">
                            <div class="d-flex justify-content-between align-items-start">
                                <div class="flex-grow-1">
                                    <h6>{{ $report->concept }}</h6>
                                    <p class="small mb-1">{{ Str::limit($report->description, 100) }}</p>
                                    <p class="small text-muted mb-0">
                                        {{ $report->upvotes }} upvotes • 
                                        {{ $report->proposals->count() }} proposals • 
                                        by {{ $report->user->name }}
                                    </p>
                                </div>
                                <div class="ms-3 d-flex gap-2">
                                    <form action="{{ route('admin.friction.select', $report) }}" method="POST" class="d-inline">
                                        @csrf
                                        <button type="submit" class="btn btn-sm btn-success" title="Select for voting">
                                            ✓
                                        </button>
                                    </form>
                                    <form action="{{ route('admin.friction.reject', $report) }}" method="POST" class="d-inline">
                                        @csrf
                                        <button type="submit" class="btn btn-sm btn-danger" title="Reject" 
                                                onclick="return confirm('Reject this report?')">
                                            ✗
                                        </button>
                                    </form>
                                </div>
                            </div>
                            
                            @if($report->proposals->count() > 0)
                                <div class="mt-2">
                                    <button class="btn btn-sm btn-outline-primary" type="button" 
                                            data-bs-toggle="collapse" data-bs-target="#proposals-{{ $report->id }}">
                                        View Proposals ({{ $report->proposals->count() }})
                                    </button>
                                    <button class="btn btn-sm btn-success" data-bs-toggle="modal" 
                                            data-bs-target="#createPollModal-{{ $report->id }}">
                                        Create Poll
                                    </button>
                                </div>
                                
                                <div class="collapse mt-2" id="proposals-{{ $report->id }}">
                                    @foreach($report->proposals as $proposal)
                                        <div class="card card-body small mb-1">
                                            <strong>{{ $proposal->proposed_root }}</strong> by {{ $proposal->user->name }}
                                            @if($proposal->justification)
                                                <br>{{ $proposal->justification }}
                                            @endif
                                        </div>
                                    @endforeach
                                </div>

                                <!-- Create Poll Modal -->
                                <div class="modal fade" id="createPollModal-{{ $report->id }}" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Create Poll for "{{ $report->concept }}"</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <form action="{{ route('admin.poll.create', $report) }}" method="POST">
                                                @csrf
                                                <div class="modal-body">
                                                    <div class="mb-3">
                                                        <label class="form-label">Start Date & Time</label>
                                                        <input type="datetime-local" class="form-control" name="starts_at" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label">End Date & Time</label>
                                                        <input type="datetime-local" class="form-control" name="ends_at" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label">Minimum Votes (Optional)</label>
                                                        <input type="number" class="form-control" name="min_votes" min="1" 
                                                               placeholder="Leave empty for time-based only">
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                    <button type="submit" class="btn btn-primary">Create Poll</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            @endif
                        </div>
                    @empty
                        <p class="text-muted">No pending reports.</p>
                    @endforelse
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card mb-4">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0">Active Polls</h5>
                </div>
                <div class="card-body">
                    @forelse($activePolls as $poll)
                        <div class="border-bottom pb-3 mb-3">
                            <h6>{{ $poll->frictionReport->concept }}</h6>
                            <p class="small mb-1">
                                <strong>Ends:</strong> {{ $poll->ends_at->format('M d, Y g:i A') }} 
                                ({{ $poll->ends_at->diffForHumans() }})
                            </p>
                            <p class="small mb-2">
                                <strong>Votes:</strong> {{ $poll->votes()->distinct('user_id')->count() }}
                                @if($poll->min_votes)
                                    / {{ $poll->min_votes }} required
                                @endif
                            </p>
                            <div class="d-flex gap-2">
                                <a href="{{ route('polls.show', $poll) }}" class="btn btn-sm btn-primary">View Poll</a>
                                <form action="{{ route('admin.poll.close', $poll) }}" method="POST" class="d-inline">
                                    @csrf
                                    <button type="submit" class="btn btn-sm btn-warning" 
                                            onclick="return confirm('Close this poll and add winner to dictionary?')">
                                        Close & Finalize
                                    </button>
                                </form>
                            </div>
                        </div>
                    @empty
                        <p class="text-muted">No active polls.</p>
                    @endforelse
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Quick Actions</h5>
                </div>
                <div class="card-body">
                    <a href="{{ route('admin.dictionary') }}" class="btn btn-primary btn-block mb-2 w-100">
                        Manage Dictionary
                    </a>
                    <button class="btn btn-success btn-block mb-2 w-100" data-bs-toggle="modal" 
                            data-bs-target="#createSectionModal">
                        Create Forum Section
                    </button>
                    <a href="{{ route('friction.index') }}" class="btn btn-info btn-block w-100">
                        View All Friction Reports
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Create Section Modal -->
<div class="modal fade" id="createSectionModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Create Forum Section</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="{{ route('admin.forum.section.create') }}" method="POST">
                @csrf
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Name</label>
                        <input type="text" class="form-control" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Slug</label>
                        <input type="text" class="form-control" name="slug" required>
                        <div class="form-text">URL-friendly name (e.g., "advanced-topics")</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea class="form-control" name="description" rows="2"></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Display Order</label>
                        <input type="number" class="form-control" name="order" value="1" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Create Section</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection