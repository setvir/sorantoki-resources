@extends('layouts.app')

@section('title', 'Friction Reports')

@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1>Friction Reports</h1>
            <p class="text-muted">Community-identified concepts that need new words</p>
        </div>
        <a href="{{ route('friction.create') }}" class="btn btn-primary">Submit New Report</a>
    </div>

    <div class="alert alert-info">
        <strong>How it works:</strong> Submit concepts that need new words. The community upvotes the most needed ones. 
        Every Sunday, curators select 3-5 top concepts for root proposals and voting.
    </div>

    @forelse($reports as $report)
        <div class="card mb-3">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-8">
                        <h5 class="card-title">{{ $report->concept }}</h5>
                        <p class="card-text">{{ $report->description }}</p>
                        
                        @if($report->examples)
                            <div class="small text-muted">
                                <strong>Examples:</strong> {{ Str::limit($report->examples, 150) }}
                            </div>
                        @endif

                        <div class="mt-2">
                            <small class="text-muted">
                                Submitted by {{ $report->user->name }} on {{ $report->created_at->format('M d, Y') }}
                            </small>
                        </div>

                        @if($report->proposals->count() > 0)
                            <div class="mt-2">
                                <span class="badge bg-info">{{ $report->proposals->count() }} proposals</span>
                            </div>
                        @endif
                    </div>

                    <div class="col-md-4 text-end">
                        <div class="display-6 text-primary">{{ $report->upvotes }}</div>
                        <div class="text-muted small">upvotes</div>
                        
                        <form action="{{ route('friction.upvote', $report) }}" method="POST" class="mt-2">
                            @csrf
                            <button type="submit" class="btn btn-sm btn-outline-primary">
                                👍 Upvote
                            </button>
                        </form>

                        @if($report->status === 'selected')
                            <span class="badge bg-success mt-2">Selected for voting</span>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    @empty
        <div class="alert alert-warning">
            No friction reports yet. Be the first to submit one!
        </div>
    @endforelse

    <div class="mt-4">
        {{ $reports->links() }}
    </div>
</div>
@endsection