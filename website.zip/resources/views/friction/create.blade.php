@extends('layouts.app')

@section('title', 'Submit Friction Report')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <h1>Submit Friction Report</h1>
            <p class="text-muted">Identify a concept that needs a new word in Sorantoki</p>

            <div class="card">
                <div class="card-body">
                    <form action="{{ route('friction.store') }}" method="POST">
                        @csrf

                        <div class="mb-3">
                            <label for="concept" class="form-label">Concept Name</label>
                            <input type="text" 
                                   class="form-control @error('concept') is-invalid @enderror" 
                                   id="concept" 
                                   name="concept" 
                                   value="{{ old('concept') }}"
                                   placeholder="e.g., 'procrastination', 'cozy', 'sibling'"
                                   required>
                            @error('concept')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <div class="form-text">A short name for the concept</div>
                        </div>

                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control @error('description') is-invalid @enderror" 
                                      id="description" 
                                      name="description" 
                                      rows="4"
                                      required>{{ old('description') }}</textarea>
                            @error('description')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <div class="form-text">Explain why this concept needs a word and what it means</div>
                        </div>

                        <div class="mb-3">
                            <label for="examples" class="form-label">Examples (Optional)</label>
                            <textarea class="form-control @error('examples') is-invalid @enderror" 
                                      id="examples" 
                                      name="examples" 
                                      rows="3">{{ old('examples') }}</textarea>
                            @error('examples')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <div class="form-text">How this concept is expressed in other languages (English, Spanish, etc.)</div>
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">Submit Report</button>
                            <a href="{{ route('friction.index') }}" class="btn btn-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection