<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\DictionaryController;
use App\Http\Controllers\FrictionReportController;
use App\Http\Controllers\RootProposalController;
use App\Http\Controllers\PollController;
use App\Http\Controllers\ForumController;
use App\Http\Controllers\Admin\DashboardController;

Auth::routes();

// Public routes
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/grammar', [HomeController::class, 'grammar'])->name('grammar');
Route::get('/liscence', [HomeController::class, 'lisence'])->name('lisence');

// Dictionary routes
Route::get('/dictionary', [DictionaryController::class, 'index'])->name('dictionary.index');
Route::get('/dictionary/search', [DictionaryController::class, 'search'])->name('dictionary.search');
Route::get('/dictionary/{entry}', [DictionaryController::class, 'show'])->name('dictionary.show');

// Forum routes
Route::get('/forum', [ForumController::class, 'index'])->name('forum.index');
Route::get('/forum/{section}', [ForumController::class, 'section'])->name('forum.section');
Route::get('/forum/{section}/post/{post}', [ForumController::class, 'show'])->name('forum.post.show');

// Authenticated routes
Route::middleware('auth')->group(function () {
    // Friction reports
    Route::get('/friction-reports', [FrictionReportController::class, 'index'])->name('friction.index');
    Route::get('/friction-reports/create', [FrictionReportController::class, 'create'])->name('friction.create');
    Route::post('/friction-reports', [FrictionReportController::class, 'store'])->name('friction.store');
    Route::post('/friction-reports/{report}/upvote', [FrictionReportController::class, 'upvote'])->name('friction.upvote');
    
    // Root proposals
    Route::post('/friction-reports/{report}/proposals', [RootProposalController::class, 'store'])->name('proposals.store');
    
    // Polls
    Route::get('/polls', [PollController::class, 'index'])->name('polls.index');
    Route::get('/polls/{poll}', [PollController::class, 'show'])->name('polls.show');
    Route::post('/polls/{poll}/vote', [PollController::class, 'vote'])->name('polls.vote');
    
    // Forum - authenticated actions
    Route::post('/forum/{section}/posts', [ForumController::class, 'storePost'])->name('forum.post.store');
    Route::post('/forum/posts/{post}/comments', [ForumController::class, 'storeComment'])->name('forum.comment.store');
});

// Admin routes
Route::middleware(['auth', 'admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
    
    // Dictionary management
    Route::get('/dictionary', [DashboardController::class, 'dictionary'])->name('dictionary');
    Route::post('/dictionary', [DashboardController::class, 'storeDictionary'])->name('dictionary.store');
    Route::put('/dictionary/{entry}', [DashboardController::class, 'updateDictionary'])->name('dictionary.update');
    Route::delete('/dictionary/{entry}', [DashboardController::class, 'deleteDictionary'])->name('dictionary.delete');
    
    // Friction report management
    Route::post('/friction-reports/{report}/select', [DashboardController::class, 'selectFrictionReport'])->name('friction.select');
    Route::post('/friction-reports/{report}/reject', [DashboardController::class, 'rejectFrictionReport'])->name('friction.reject');
    
    // Poll management
    Route::post('/friction-reports/{report}/create-poll', [DashboardController::class, 'createPoll'])->name('poll.create');
    Route::post('/polls/{poll}/close', [DashboardController::class, 'closePoll'])->name('poll.close');
    
    // Forum management
    Route::post('/forum/sections', [DashboardController::class, 'createSection'])->name('forum.section.create');
    Route::delete('/forum/posts/{post}', [DashboardController::class, 'deletePost'])->name('forum.post.delete');
});
